a = input()
b = input()
def first_last(letter, st):
    fc=0
    mayfc=1
    1c=0
    for i in range(len(st)):
        if letter in st[i]:
            if maufc==1:
                fc=i 
                mayfc=0
            1c=i
    return (fc, 1c)
print (first_last(a,b))