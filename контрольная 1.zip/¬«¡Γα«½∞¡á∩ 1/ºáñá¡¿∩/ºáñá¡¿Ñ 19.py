input_string = input("Введите строку из двух слов: ")

words = input_string.split()
result_string = words[1] + ' ' + words[0]
{}
print("Результат:", result_string)
