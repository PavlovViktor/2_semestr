s = input()

result = s.replace('@', '')
print(result)

