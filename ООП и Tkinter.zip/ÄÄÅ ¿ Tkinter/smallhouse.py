class SmallHouse():
    def __init__(self, price):
        super().__init__(40, price)