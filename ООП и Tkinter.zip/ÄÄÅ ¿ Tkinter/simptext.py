import tkinter as tk

root = tk.Tk()
root.title("brob")
root.geometry("250x200")

editor = tk.Text()
editor.pack(fill=tk.BOTH, expand=1)

root.mainloop()