class TArray:
    def __init__(self, *elements):
        if elements and isinstance(elements[0], TArray):
            self.elements = elements[0].elements.copy()
        else:
            self.elements = list(elements)
    
    def add_element(self, value):
        self.elements.append(value)
    
    def print_array(self):
        print("Массив:", self.elements)
    
    def find_max(self):
        return max(self.elements) if self.elements else None
    
    def find_min(self):
        return min(self.elements) if self.elements else None
    
    def sort_array(self):
        self.elements.sort()
    
    def calculate_sum(self):
        return sum(self.elements)
    
    def __add__(self, value):
        new_array = TArray(*self.elements)
        new_array.add_element(value)
        return new_array
    
    def __mul__(self, num):
        return TArray(*[x * num for x in self.elements])
    
    def __str__(self):
        return f"Элементы: {self.elements}"


if __name__ == "__main__":
    a = TArray(3, 1, 4, 2)
    b = TArray(a)  
    
    print("Массив a:", a)
    print("Массив b (копия a):", b)
    
    a.add_element(5)
    print("a после добавления 5:", a)
    
    print("\nМаксимальный элемент:", a.find_max())
    print("Минимальный элемент:", a.find_min())
    print("Сумма элементов:", a.calculate_sum())
    
    a.sort_array()
    print("\nПосле сортировки:")
    a.print_array()
    
    c = a + 6  
    print("\nМассив c (a + 6):", c)
    
    d = a * 2  
    print("Массив d (a * 2):", d)