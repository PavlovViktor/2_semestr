import tkinter as tk
from tkinter import ttk, messagebox
import string

class Human:
    default_name = "Иван"
    default_age = 30

    def __init__(self, name=default_name, age=default_age):
        self.name = name
        self.age = age
        self.__money = 0
        self.__house = None

    def info(self):
        return f"Имя: {self.name}, Возраст: {self.age}, Дом: {self.__house}, Деньги: {self.__money}"

    @staticmethod
    def default_info():
        return f"Default name: {Human.default_name}, Default age: {Human.default_age}"

    def __make_deal(self, house, price):
        self.__money -= price
        self.__house = house

    def earn_money(self, amount):
        self.__money += amount
        return f"Заработано {amount}. Текущий баланс: {self.__money}"

    def buy_house(self, house, discount):
        final_price = house.final_price(discount)
        if self.__money >= final_price:
            self.__make_deal(house, final_price)
            return "Дом куплен!"
        else:
            return "Недостаточно денег для покупки дома"

class House:
    def __init__(self, area, price):
        self._area = area
        self._price = price

    def final_price(self, discount):
        return self._price * (100 - discount) / 100

class SmallHouse(House):
    def __init__(self, price):
        super().__init__(40, price)

class Alphabet:
    def __init__(self, lang, letters):
        self.lang = lang
        self.letters = letters

    def print(self):
        return self.letters

    def letters_num(self):
        return len(self.letters)
