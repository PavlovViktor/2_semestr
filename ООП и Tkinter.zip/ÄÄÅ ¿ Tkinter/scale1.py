import tkinter as tk
from tkinter import ttk

root = tk.Tk()
root.title("brob")
root.geometry("250x200")

val = tk.IntVar(value=10)

label = ttk.Label(textvariable=val)
label.pack(anchor=tk.NW)

horizontal_scale = ttk.Scale(orient=tk.HORIZONTAL, length=200, from_=1.0, to=100.0, variable=val)
horizontal_scale.pack(anchor=tk.NW)

root.mainloop()