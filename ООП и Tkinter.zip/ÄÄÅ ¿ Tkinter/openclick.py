import tkinter as tk
from tkinter import ttk

root = tk.Tk()
root.title("brobi")
root.geometry("250x200")

def open_new_window():
    window = tk.Tk()
    window.title("Второе окно")
    window.geometry("250x200")

button = ttk.Button(text="Открыть окно", command=open_new_window)
button.pack(anchor=tk.CENTER, expand=1)

root.mainloop()