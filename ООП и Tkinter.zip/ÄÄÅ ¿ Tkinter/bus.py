class Bus:
    def __init__(self, speed=0, capacity=30, max_speed=90):
        self.speed = speed
        self.capacity = capacity
        self.max_speed = max_speed
        self.passengers = []
        self.seats = {i: None for i in range(1, capacity + 1)}
    
    @property
    def has_empty_seats(self):
        return len(self.passengers) < self.capacity
    
    def board_passenger(self, name, seat=None):
        if not self.has_empty_seats:
            print("Автобус заполнен!")
            return False
        
        if seat is None:
            for seat_num, passenger in self.seats.items():
                if passenger is None:
                    seat = seat_num
                    break
        
        if seat in self.seats and self.seats[seat] is None:
            self.seats[seat] = name
            self.passengers.append(name)
            print(f"{name} сел на место {seat}")
            return True
        else:
            print(f"Место {seat} уже занято или не существует")
            return False
    
    def board_passengers(self, *names):
        for name in names:
            if not self.has_empty_seats:
                print("Не все пассажиры смогли войти - автобус заполнен!")
                break
            self.board_passenger(name)
    
    def disembark_passenger(self, name):
        if name in self.passengers:
            for seat_num, passenger in self.seats.items():
                if passenger == name:
                    self.seats[seat_num] = None
                    break
            self.passengers.remove(name)
            print(f"{name} вышел из автобуса")
            return True
        else:
            print(f"Пассажир {name} не найден в автобусе")
            return False
    
    def disembark_passengers(self, *names):
        for name in names:
            self.disembark_passenger(name)
    
    def increase_speed(self, amount):
        new_speed = self.speed + amount
        if new_speed > self.max_speed:
            print(f"Нельзя превысить максимальную скорость {self.max_speed}!")
            self.speed = self.max_speed
        else:
            self.speed = new_speed
        print(f"Текущая скорость: {self.speed}")
    
    def decrease_speed(self, amount):
        new_speed = self.speed - amount
        if new_speed < 0:
            print("Скорость не может быть отрицательной!")
            self.speed = 0
        else:
            self.speed = new_speed
        print(f"Текущая скорость: {self.speed}")
    
    def __contains__(self, name):
        return name in self.passengers
    
    def __iadd__(self, name):
        self.board_passenger(name)
        return self
    
    def __isub__(self, name):
        self.disembark_passenger(name)
        return self
    
    def __str__(self):
        return (f"Автобус (скорость: {self.speed}/{self.max_speed}, "
                f"пассажиров: {len(self.passengers)}/{self.capacity})")