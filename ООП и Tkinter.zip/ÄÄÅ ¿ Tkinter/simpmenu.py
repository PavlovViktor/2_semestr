import tkinter as tk

root = tk.Tk()
root.title("brob")
root.geometry("250x150")

menu = tk.Menu(root)
root.config(menu=menu)

file_menu = tk.Menu(menu)
menu.add_cascade(label="Файл", menu=file_menu)
file_menu.add_command(label="Новый")
file_menu.add_command(label="Сохранить")
file_menu.add_command(label="Открыть")
file_menu.add_separator()
file_menu.add_command(label="Выход")

root.mainloop()