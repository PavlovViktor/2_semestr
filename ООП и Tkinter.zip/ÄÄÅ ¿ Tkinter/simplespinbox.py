import tkinter as tk
from tkinter import ttk

root = tk.Tk()
root.title("brob")
root.geometry("250x200")

spinbox = ttk.Spinbox(from_=1.0, to=100.0)
spinbox.pack(anchor=tk.NW)

root.mainloop()