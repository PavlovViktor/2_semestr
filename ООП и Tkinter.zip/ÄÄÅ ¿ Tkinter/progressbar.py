import tkinter as tk
from tkinter import ttk

root = tk.Tk()
root.title("brob")
root.geometry("250x150")

progress_bar = ttk.Progressbar(mode='indeterminate')
progress_bar.pack(fill=tk.BOTH, expand=1)

start_button = ttk.Button(text="Запустить", command=progress_bar.start)
start_button.pack(side=tk.LEFT, expand=1)

stop_button = ttk.Button(text="Останавливать", command=progress_bar.stop)
stop_button.pack(side=tk.RIGHT, expand=1)

root.mainloop()