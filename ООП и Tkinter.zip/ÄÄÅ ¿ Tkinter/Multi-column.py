import tkinter as tk
from tkinter import ttk

root = tk.Tk()
root.title("brobis")
root.geometry("250x200")

people = [
    ("brob1s", 38, "brob1@example.com"),
    ("brob2s", 42, "brob2@example.com"),
    ("brob3s", 28, "brob3@example.com")
]

columns = ("name", "age", "email")

tree = ttk.Treeview(columns=columns, show="headings")
tree.pack(fill=tk.BOTH, expand=1)

tree.heading("name", text="Имя")
tree.heading("age", text="Возраст")
tree.heading("email", text="Почта")

for person in people:
    tree.insert("", tk.END, values=person)

root.mainloop()
