import tkinter as tk
from tkinter import ttk

root = tk.Tk()
root.title("METANIT.COM")
root.geometry("250x250")

vertical_scale = ttk.Scale(orient=tk.VERTICAL, length=200, from_=1.0, to=100.0, value=50)
vertical_scale.pack()

horizontal_scale = ttk.Scale(orient=tk.HORIZONTAL, length=200, from_=1.0, to=100.0, value=30)
horizontal_scale.pack()

root.mainloop()