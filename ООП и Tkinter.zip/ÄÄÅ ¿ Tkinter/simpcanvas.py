import tkinter as tk

root = tk.Tk()
root.title("brobi")
root.geometry("300x300")

canvas = tk.Canvas(bg="white", width=250, height=250)
canvas.pack(anchor=tk.CENTER, expand=1)

canvas.create_line(10, 10, 200, 50)

root.mainloop()