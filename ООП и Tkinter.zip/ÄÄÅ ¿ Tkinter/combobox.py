import tkinter as tk
from tkinter import ttk

root = tk.Tk()
root.title("METANIT.COM")
root.geometry("250x200")

languages = ["Python", "C#", "Java", "JavaScript"]
languages_var = tk.StringVar(value=languages)

combobox = ttk.Combobox(textvariable=languages_var, values=languages, state="readonly")
combobox.pack(anchor=tk.NW, fill=tk.X, padx=5, pady=5)

label = ttk.Label(text=f"Выбран: {languages_var.get()}")
label.pack(anchor=tk.NW, fill=tk.X, padx=5, pady=5)

root.mainloop()