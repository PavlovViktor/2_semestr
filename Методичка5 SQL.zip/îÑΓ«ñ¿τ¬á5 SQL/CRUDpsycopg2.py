import psycopg2
from psycopg2 import Error

try:
    connection = psycopg2.connect(user="postgres",
                                password="5356",
                                host="localhost",
                                port="5432",
                                database="postgres_db")
    cursor = connection.cursor()

    insert_query = """ INSERT INTO mobile (ID, MODEL, PRICE) VALUES (1, 'Iphone12', 1100)"""
    cursor.execute(insert_query)
    connection.commit()
    print("1 запись успешно вставлена")
    

    cursor.execute("SELECT * from mobile")
    record = cursor.fetchall()
    print("Результат", record)

    update_query = """Update mobile set price = 1500 where id = 1"""
    cursor.execute(update_query)
    connection.commit()
    count = cursor.rowcount
    print(count, "Запись успешно обновлена")

    delete_query = """Delete from mobile where id = 1"""
    cursor.execute(delete_query)
    connection.commit()
    count = cursor.rowcount
    print(count, "Запись успешно удалена")
    
except (Exception, Error) as error:
    print("Ошибка при работе с PostgreSQL", error)
finally:
    if connection:
        cursor.close()
        connection.close()
        print("Соединение с PostgreSQL закрыто")