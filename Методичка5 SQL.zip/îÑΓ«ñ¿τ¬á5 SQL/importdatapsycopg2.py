import psycopg2
from psycopg2 import Error

try:
    connection = psycopg2.connect(
        user="postgres",
        password="5356",
        host="localhost",
        port="5432",
        database="postgres_db"
    )

    cursor = connection.cursor()
    insert_query = """
    INSERT INTO products(product_name, price) VALUES(%s, %s);
    """
    values_to_insert = [
        ("Product A", 19.99),
        ("Product B", 29.99)
    ]
    cursor.executemany(insert_query, values_to_insert)
    connection.commit()
    print("Records inserted successfully!")

except Exception as err:
    print("Ошибка записи:", err)

finally:
    if connection:
        cursor.close()
        connection.close()
        print("PostgreSQL подключение закрыто.")