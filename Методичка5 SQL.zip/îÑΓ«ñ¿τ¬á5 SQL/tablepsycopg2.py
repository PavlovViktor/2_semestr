import psycopg2
from psycopg2 import Error

try:
    connection = psycopg2.connect(
        user="postgres",
        password="5356",
        host="localhost",
        port="5432",
        database="postgres_db"
    )

    cursor = connection.cursor()
    create_table_query = """
    CREATE TABLE IF NOT EXISTS products (
        product_id SERIAL PRIMARY KEY,
        product_name VARCHAR(100),
        price DECIMAL(10, 2)
    );
    """
    cursor.execute(create_table_query)
    connection.commit()
    print("Таблица успешно создана")

except Exception as err:
    print("Ошибка при созаднии таблица:", err)

finally:
    if connection:
        cursor.close()
        connection.close()
        print("PostgreSQL подключение закрыто.")