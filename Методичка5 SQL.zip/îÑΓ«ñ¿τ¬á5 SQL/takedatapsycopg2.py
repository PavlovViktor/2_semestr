import psycopg2
from psycopg2 import Error

try:
    connection = psycopg2.connect(user="postgres",
                                password="5356",
                                host="localhost",
                                port="5432",
                                database="postgres_db")
    cursor = connection.cursor()
    postgreSQL_select_Query = "select * from mobile"
    cursor.execute(postgreSQL_select_Query)
    mobile_records = cursor.fetchall()
    
    print("Вывод каждой строки и ее столбцов")
    for row in mobile_records:
        print("Id =", row[0])
        print("Модель =", row[1])
        print("Цена =", row[2], "\n")
        
except (Exception, Error) as error:
    print("Ошибка при работе с PostgreSQL", error)
finally:
    if connection:
        cursor.close()
        connection.close()
        print("Соединение с PostgreSQL закрыто")