import psycopg2
from psycopg2 import Error

try:
    connection = psycopg2.connect(
        user="postgres",
        password="5356",
        host="localhost",
        port="5432",
        database="postgres_db"
    )
    
    cursor = connection.cursor()
    cursor.execute("SELECT version();")
    record = cursor.fetchone()
    print("Connected to:", record)

except Exception as err:
    print("ошибка подключения PostgreSQL:", err)

finally:
    if connection:
        cursor.close()
        connection.close()
        print("PostgreSQL подключение закрыто.")