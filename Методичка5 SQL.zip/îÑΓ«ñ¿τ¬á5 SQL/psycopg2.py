import psycopg2
from psycopg2 import Error
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT

try:
    connection = psycopg2.connect(
        user="postgres",
        password="5356",
        host="localhost",
        port="5432"
    )
    connection.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)

    cursor = connection.cursor()
    cursor.execute('CREATE DATABASE')

except Exception as err:
    print("Ошибка создания бд:", err)

finally:
    if connection:
        cursor.close()
        connection.close()
        print("PostgreSQL подключение закрыто.")