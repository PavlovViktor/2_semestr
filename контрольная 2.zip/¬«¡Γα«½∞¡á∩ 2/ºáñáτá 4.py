bold = lambda func:(lambda text: 
                    f"**{func(text)}**")
italic = lambda func:(lambda text: 
                    f"*{func(text)}*")
underline = lambda func:(lambda text:
                         f"_{func(text)}_")

display_text = bold(italic(underline(lambda text: text)))

result = display_text("Hello, World!")
print(result)