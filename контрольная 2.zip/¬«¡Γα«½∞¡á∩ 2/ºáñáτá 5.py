code = input("Введите код:")
exec(code)

