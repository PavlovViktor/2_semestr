my_list = [1, 2, 3, 4, 5]
total = 0

for number in my_list:
    total += number  

print(f"Сумма: {total}.")


