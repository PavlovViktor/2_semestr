number = int(input("Ваше число: "))

if number % 2 == 0:
    print(f"Число {number} четное: True.")
else:
    print(f"Число {number} четное: False.")
