n = 8  
a, b = 1, 1

if n == 1 or n == 2:
    result = 1
else:
    for _ in range(3, n + 1):
        a, b = b, a + b  
    result = b  

print(f"{n}-е число Фибоначчи: {result}.")
