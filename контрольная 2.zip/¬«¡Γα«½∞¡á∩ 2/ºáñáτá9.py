a = float(input())
b = float(input())

perimetr = 2 * (a + b)

print(f"Периметр прямоугольника со сторонами {a} и {b} равен {perimetr}.")
