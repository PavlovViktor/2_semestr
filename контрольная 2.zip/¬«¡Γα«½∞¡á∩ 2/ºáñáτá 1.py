sentence = "Hello"
alphabet = set("abcdefghijklmnopqrsyuvwxyz")
sentence_set = set(sentence.lower())
is_pangram = alphabet.issubset(sentence_set)

print(is_pangram)