N = 5  

result = 1  
for i in range(1, N + 1):
    result *= i  

print(f"Факториал числа {N} равен: {result}.")
